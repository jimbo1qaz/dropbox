import gauss
import math
import numpy as np
from global_util import *

MAXN = 10
MAXY = 16
EXP = 2


def geometric2(echo2, efb2, i):
    # calculate sum((echo * efb^i)**2)
    #         = sum(echo2 * efb2^i)
    echo2 *= efb2 ** max(i, 0)

    out2 =  echo2 / (1-efb2)
    if i < 0:
        out2 += 1
    return out2

# | 10 / 10 5 5 5 3 3 3 3 3 3 2 2 2 1 1 1 1 1 1 1 1 1 0

DELAY = 3
ECHO = 0.3125
EFB = 0.78125

def echo2(sustain, delay=DELAY, echo=ECHO, efb=EFB):
    echo2 = echo ** EXP
    efb2 = efb ** EXP
    del echo, efb

    # attack2 = []



    # # 1 + echo + echo*efb^i...
    # attack2 += [1] * delay

    # for i in range(0, MAXN):
    #     y = attack2[-1] + (echo * efb**i)
    #     attack2 += [y] * delay

    asdf2 = []
    # echo, echo*efb...
    start = (0 if sustain else -1)

    for i in range(start, MAXN):
        sum_sq = geometric2(echo2, efb2, i)
        asdf2 += [sum_sq] + [0] * (delay-1)

    return ar(asdf2)

def echo_calc(initial=None, delay=DELAY, echo=ECHO, efb=EFB, *, maximum=None, signal=None, sustain=True, early=None):
    if signal is None:
        signal = [1] * delay

    signal2 = ar(signal) ** 2
    del signal

    asdf2 = echo2(False, delay, echo, efb)   # sustain FIXME
    asdf2 = np.convolve(asdf2, signal2)

    # do the range-range
    if initial is not None:
        asdf = np.sqrt(asdf2) * initial
    else:
        asdf = np.sqrt(asdf2)
        asdf /= max(asdf)
        asdf *= maximum

    if early == 'unrounded':
        return asdf
    if early == 'rounded':
        return gauss.iround(asdf)

    out = S(gauss.iround(asdf))
    # if sustain:
    #     out = f'| {initial} / {initial} {out}'
    return out


MAXVOL = 15
organ = A(0x20, 0x14+.5, 0x11) / 0x20 * 15
organ = ROUND(organ)

print('organ')
for initial in organ:
    print(echo_calc(maximum=initial))
print()


print('tambourine noise')
# 18
# print(echo_calc(10, echo=ECHO, sustain=False,
#     signal=[.9, .8, .6, .4, .3, .2, .1]))
print(echo_calc(echo=ECHO, sustain=False,
    # initial=9, signal=[1, .4, .2]))
    initial=7, signal=[1, .4, .2]))


print('tambourine wavetable')
print(echo_calc(echo=ECHO, sustain=False,
    # initial=9, signal=[
    #     0.3, 0.4, 0.4,
    #     0.3, 0.25, 0.2,
    #     0.1, 0.05, 0.02,
    #     0.01
    # ]
    # initial=9, signal=[
    #     0.9, 0.8, 0.5,
    #     0.3, 0.25, 0.2,
    #     0.1, 0.05, 0.02,
    #     0.01
    # ]
    initial=9, signal=[0.9, 0.8, 0.5, 0.3, 0.25, 0.2, 0.1, 0.05, 0.02, 0.01]))


print(echo_calc(sustain=False,
    initial=7, signal=[0.9, 0.8, 0.5, 0.3, 0.25, 0.2, 0.1, 0.05, 0.02, 0.01]))
# print(echo_calc(11, echo=ECHO, sustain=False,
#     signal=[1, .6, .4]))
print()





for i in range(3): print()
print('music box')
fuck = echo_calc(sustain=False, maximum=1, echo=32/40, efb=0x3c/0x80, delay=1, early='unrounded',

    signal=[ 1., 0.77234978, 0.59110894, 0.45139228, 0.34000977, 0.24914509, 0.1875916, 0.12701514, 0.09526136, 0.06497313, 0.03419638, 0.00390816]
)

print(list(fuck))
# print(S(hex(i)[2:] for i in fuck))


for i in range(3): print()
for i in range(3): print()
print('trumpet')
print(echo_calc(sustain=False,
    initial=14.5, signal=[0.5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))


print('trumpet staccato')
print(echo_calc(sustain=False,
    # initial=14.5, signal=[0.5, 1, 1, 1, 0.5]))
    initial=14.5, signal=[0.5, 1, 1, 1, 0.5]))

