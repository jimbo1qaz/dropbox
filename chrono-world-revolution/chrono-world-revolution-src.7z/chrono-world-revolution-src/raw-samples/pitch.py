from scipy.io import wavfile
from numpy import logical_and, average, diff
from matplotlib.mlab import find

start_brr = 3
start_smp = start_brr * 16

def get_pitch(ys):
    indices = logical_and(ys[1:] >= 0, ys[:-1] < 0)
    indices2 = logical_and(ys[1:] < 0, ys[:-1] >= 0)

    crossings = sum(indices)
    crossings2 = sum(indices2)
    return crossings, crossings2

rate, ys = wavfile.read('strings-sine-looped.wav')
# ys = ys[:]
print(get_pitch(ys))


# 829 Loop : 3.
397/826
