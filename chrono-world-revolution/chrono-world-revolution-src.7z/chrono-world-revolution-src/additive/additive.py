import numpy as np

import sys
sys.path.append("..")   # kill me
import gauss
from global_util import *

import matplotlib.pyplot as plt


PI = np.pi
PI2 = 2 * np.pi

MAXY = 16


def grouper(n, iterable, fillvalue=None):
    "grouper(3, 'ABCDEFG', 'x') --> ABC DEF Gxx"
    args = [iter(iterable)] * n
    return izip_longest(fillvalue=fillvalue, *args)


def timeify(freq_amp):
    def freq_amps(freq, *amps):
        return [freq_amp(freq, amp) for amp in amps]
    return freq_amps


@timeify
def sine(freq, amp):
    return lambda xs: amp * np.real(np.exp(1j * freq * xs))


@timeify
def square(freq, amp):
    def _square(xs):
        thetas = xs * freq + 0.000001
        stuff = np.floor(thetas / np.pi)
        return -1 ** stuff
    return _square





# EXPONENT = 2
# def cost(nearest, freqs):
#     fourier = abs(np.fft.rfft(nearest))
#     signal = sum(fourier[freqs] ** EXPONENT)
#     noise = sum(fourier ** EXPONENT) - signal

#     cost = noise / signal



# SAMPLES = 16
# Nyquist = 8
# If samples = 24, nyquist = 12, throw in square(12,6,4)

samples1 = 16
osc1 = safezip(
    sine(3,  0.1 ,  0.1 ),
    sine(4, -0.09, -0.1 ),
    sine(6,  0   ,  0.02),
    sine(7,  0.07,  0.04)
)

samples2 = 24
osc2 = safezip(
    sine(4,1),
    sine(6,1),
    sine(12,1)
)

def generate(samples, oscillators):
    xs = RANGE(0, PI2, samples) + PI/samples
    ys = 0 * xs

    for osc in oscillators:
        ys += osc(xs)

    return ys


for oscs in time_oscillators:
    ys = generate(oscs)
    ys_scaled = ys / max(ys)
    # plt.plot(abs(np.fft.rfft(ys_scaled)))

    out = gauss.rescale_quantize(ys)
    out_scaled = 2*out / max(out) - 1
    # plt.plot(abs(np.fft.rfft(out_scaled)))
    # plt.show()

    print(S(out))
