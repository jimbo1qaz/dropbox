out = []

n = 15
ratios = [1]*5 + [0.75]*5
ratios[0] = 1.1
ratios[3] = 1.1
ratios[9] = 0.88

with open('11-zamual.txt') as f:
	for l in f:
		if l[:4] != 'ROW ':
			out.append(l)
			continue

		out.append(l[:6])
		l = l[6:-1]
		# assert len(l) == 10*n
		# print(l)
		for i in range(0, len(l)//n):
			# if i//n not in range(5,9):
			# 	out[-1] += l[i: i+n]
			# 	continue

			s = list(l[i*n: (i+1)*n])
			v = s[10]
			if v != '.':
				v = round(int(v, 16) * ratios[i])
				assert v < 16
				v = hex(v)[2:]
				s[10] = v

			out[-1] += ''.join(s)

		out[-1] += '\n'

with open('12-att.txt', 'w') as f:
	f.writelines(out)
