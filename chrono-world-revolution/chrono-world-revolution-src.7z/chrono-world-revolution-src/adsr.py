import gauss
import numpy as np

from global_util import *
from fractions import Fraction


a = [   np.inf, 2048, 1536,
          1280, 1024,  768,
           640,  512,  384,
           320,  256,  192,
           160,  128,   96,
            80,   64,   48,
            40,   32,   24,
            20,   16,   12,
            10,    8,    6,
             5,    4,    3,
                   2,
                   1,]

SAMPLE_RATE = Fraction(32000)
FRAMERATE = 60
MAXY = 16


SNES_MAX = 0x7FF
# (32000/a[i] inc/s) * (1/60 s/tick) =
def tickfuck(sustain, length):
    ys = [SNES_MAX]
    # currval = 0x7FF

    prevT = 0
    for i in range(1, length):
        ticks = int(SAMPLE_RATE / a[sustain] / FRAMERATE * i)
        delta = ticks - prevT

        curr = ys[-1]
        for j in range(prevT, ticks):
            curr -= 1
            curr -= curr >> 8

        if curr < 0:
            curr = 0

        ys.append(curr)
        if curr == 0:
            break
        prevT = ticks

    return ar(ys)

def envelope(sustain, length, maxy):
    ys = tickfuck(sustain, length)
    ys = ys / SNES_MAX * maxy

    out = S(gauss.rescale_quantize(ys, maxy))
    return out

print('cymbal')
print(envelope(0x0E, 1000, 13))


# print('music box')
# print(tickfuck(0x0d, 1000) / SNES_MAX)
