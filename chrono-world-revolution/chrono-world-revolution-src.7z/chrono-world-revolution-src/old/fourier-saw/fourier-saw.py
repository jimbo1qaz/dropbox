import hashlib
import math
import random
import numpy as np
import matplotlib.pyplot as plt


# FIXME: if sum(delta^2) is constant... Then the aliasing power is constant. I'm wasting my fucking time.
# Should I judge based on rounding error?
# TODO: calculate FFT of np.LOLGAUSS, insert into BASS_BOOST, rename
# BASS_BOOST.

import sys
sys.path.append("..")   # kill me
import gauss
from global_util import *


class AttrDict(dict):
    def __init__(self, seq={}, **kwargs):
        super().__init__(seq, **kwargs)
        self.__dict__ = self


NTEST = 1000
EXPONENT = 2

MAXRANGE = 16
SNES_SAMPLES = 64


# FILTER = abs(np.fft.rfft(gauss.GAUSS, SNES_SAMPLES))
FILTER = abs(np.fft.rfft(gauss.l(64), SNES_SAMPLES))
print(FILTER)



def rand_invert():
    return random.randint(0, 1) * math.pi


DERIVATIVE = True
REPEAT_NEAREST = 8

def wave_test(samples, num_seed, invert=True):
    # Include f/2, since we're generating at a very low sampling rate.
    MAX_HARMONIC = samples // 2

    # hash = hashlib.sha256()
    seed = int2bytes(num_seed, 16)
    # hash.update(seed)
    # del seed
    # random.seed(hash.digest())
    random.seed(seed)

    rng = rand_invert
    # TODO: new function to seed.

    # **** Generate a signal ****
    xs = RANGE(0, PI2, samples) + np.pi/samples
    ys = 0 * xs
    # yprime = 0 * xs

    fft = [0] * (samples//2 + 1)
    for i in range(1, MAX_HARMONIC):
        _, phase = rng(), rng()
        # ys += np.sin(i * xs + phase) * FILTER[i] / i

        phase -= math.pi/2   # sin(x) = cos(x - pi/2)
        amp = FILTER[i] / i
        fft[i] = amp*np.exp(1j*phase)
    ys = np.fft.irfft(fft)
    assert len(ys) == len(xs)
    # repeat by REPEAT_NEAREST, fft, maximize snr?

    wavetable = gauss.rescale_quantize(ys)
    nearest = np.repeat(wavetable, REPEAT_NEAREST)
    del wavetable

    # nearest = al(wavetable[int(i*SAMPLES/NEAREST_LENGTH)] for i in range(NEAREST_LENGTH))

    fourier = abs(np.fft.rfft(nearest))
    signal = sum(fourier[:MAX_HARMONIC] ** EXPONENT)
    noise = sum(fourier ** EXPONENT) - signal

    cost = noise / signal

    # db = np.log10(fourier) / 2

    # colors = [(255,255,255) if i%4==0 else (0,0,0) for i in range(len(fourier))]
    # plot = Plotter(title='', xlabel='', ylabel='').plot(
    #     seq_along(db), db, 'none')
    # # plot.fig.show()
    # plt.show()
    # # plt.plot(np.log10(fourier) / 2, c=colors)


    return AttrDict(cost=cost, seed=num_seed, ys=ys)


def multitest(samples, seed0, invert, NTEST=NTEST):
    # (cost, seed, ys)
    best = AttrDict(cost=math.inf, seed=None, ys=None)

    for seed in range(seed0, seed0 + NTEST):
        result = wave_test(samples, seed, invert)
        if result.cost < best.cost:
            best = result

    return best




def main(infile='seeds.txt', outfile='results.txt'):
    lines = [l.strip() for l in open(infile).readlines()]

    outputs = []
    for linen, line in enumerate(lines):
        if not line:
            continue
        if line[0] in '#;':
            continue

        args = I(line)

        samples = args[0]
        seed0 = args[1]
        ntest = args[2] if len(args) > 2 else NTEST

        # * phased = multitest(seed0, invert=False)
        result = multitest(samples, seed0, invert=True, NTEST=ntest)
        cost, seed, ys = [result.cost, result.seed, result.ys]

        # * phased_out = gauss.rescale_quantize(phased[1])
        inverted_out = gauss.rescale_quantize(ys)
        # best = phased
        # best_type = 'phased'

        # if inverted[0] < phased[0]:
        #     best = inverted
        #     best_type = 'inverted'

        # cost = best[0]
        # ys = best[1]
        # print(ys)
        # ys = gauss.rescale_quantize(ys)
        # print(ys)

        output = f'''{samples}: {seed} (inverted):
    {cost}
{S(inverted_out)}
{S(MAXRANGE - inverted_out - 1)}

'''
        # phased:     {phased[0]}, {S(phased_out)}
        outputs.append(output)

    open(outfile, 'w').writelines(outputs)


if __name__ == '__main__':
    main()
