import hashlib
import random
import numpy as np
import matplotlib.pyplot as plt


# FIXME: if sum(delta^2) is constant... Then the aliasing power is constant. I'm wasting my fucking time.
# Should I judge based on rounding error?
# TODO: calculate FFT of np.LOLGAUSS, insert into BASS_BOOST, rename
# BASS_BOOST.

import sys
sys.path.append("..")   # kill me
import gauss
from global_util import *
from physics import Plotter



PI = np.pi
PI2 = 2 * np.pi

MAXRANGE = 16
SAMPLES = 48
SNES_SAMPLES = 64


FILTER = abs(np.fft.rfft(gauss.l(64), SNES_SAMPLES))
print(FILTER)
FILTER = FILTER[:SAMPLES]


# Exclude f/2, as it should be filtered out by SNES gauss.
MAX_HARMONIC = (SAMPLES - 1) // 2

phases = [0,1,1,0,1,0,0,1,1,0,0,1,0,1,1,0,1,0,0,1,0,1,1,0]
phases = [float(x) for x in phases]
phases = cat(phases, [0] * MAX_HARMONIC)
print(phases)
# phases = np.tile(ar(phases), MAX_HARMONIC)
phases *= PI
# phases += 1


def generate(SAMPLES, phases):
    xs = RANGE(0, PI2, SAMPLES) + PI/SAMPLES
    ys = 0 * xs

    for i in range(1, MAX_HARMONIC):
        phase = phases[i]
        ys += np.sin(i * xs + phase) * FILTER[i] / i

    return ys



def main():
    ys = generate(SAMPLES, phases)
    inverted_out = rescale_quantize(ys)
    print(S(inverted_out))
    print(S(MAXRANGE - inverted_out - 1))

if __name__ == '__main__':
    main()
