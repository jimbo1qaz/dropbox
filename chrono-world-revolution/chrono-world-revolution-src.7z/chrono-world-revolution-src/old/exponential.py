import numpy as np

import sys
sys.path.append("..")   # kill me
import gauss
from global_util import *


# generate(lambda i: ratio ** (i/30), n=30, print=True)
    # *= 15
    # quantize

l = []
for i in range(30):
    l.append(
        (0.007943282347242814 / 0.14125375446227545) ** (i/30)
    )

l = ar(l) * 12

asdf = gauss.quantize(l, 1000000)

print(S(asdf))
