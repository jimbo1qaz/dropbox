import numpy as np
import scipy.signal
import matplotlib.pyplot as plt


# for l in [128, 4096]:
window = scipy.signal.slepian(128, width=0.1)
window = scipy.signal.slepian(128, width=1.0)

window = scipy.signal.slepian(1024, width=0.1)
window = scipy.signal.slepian(1024, width=1.0)

plt.plot(window)
plt.show()
