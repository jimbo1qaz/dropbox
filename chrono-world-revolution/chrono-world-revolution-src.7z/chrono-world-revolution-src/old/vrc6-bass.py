import math

# for i in range(39):
#     print(i*28/39)

                # 19.530000048825 tick/wah
ticks = 20      # 20 ticks/wah
                #
fullscale = 7   # 7
wahs = 1        #
sweeps = 2*wahs # 2 sweeps/wah

s = ''

for i in range(ticks):
    # When i = ticks/sweeps, out = fullscale.
    # out = i * sweeps/ticks * fullscale.

    out = i * sweeps/ticks * fullscale
    
    # create triangle.
    out = math.fmod(out, 2*fullscale)
    if out > fullscale:
        out = 2*fullscale - out

    out = round(out)
    # print(out)
    s += str(out) + ' '

print(s)