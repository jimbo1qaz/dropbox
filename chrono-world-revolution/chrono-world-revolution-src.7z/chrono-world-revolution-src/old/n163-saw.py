from gauss import * 

MAX = 16
N = 48


# 16/64, 4/7, is it systematically biased?
def saw(y=MAX, x=N):
    return wave(0, y, x)

# def fir(arr):
#     return circular_convolve(arr, GAUSS)

# def sawtooth_fir(y=MAX, x=N):
#     raw = saw(y, x)
#     out = circular_convolve(raw, GAUSS)
#     return S(quantize(out))

# preview = compose(saw, quantize, S)
# def preview(y=MAX, x=N):
#     compose(P(saw(y,x)), )
#     print(S(quantize(saw(y, x))))


def saw_fir(y=MAX, x=N):
    raw = saw(y,x)
    return repeatedly_convolve(raw, LOLGAUSS, 1)

# preview = pipe | quantize | S | print
def SAW(y=MAX, x=N):
    output = quantize(saw(y,x), y)
    return output

def SAW_FIR(y=MAX, x=N):
    output = quantize(saw_fir(y,x), y)
    return output

# SAW(4, 7)
# SAW(16, 64)

# SAW_FIR()
sprint(saw_fir())

output = SAW_FIR()
sprint(output)
sprint(MAX - output - 1)

# 2 0 0 0 1 1 1 1 2 2 2 2 3 3 3 3 4 4 4 4 5 5 5 5 6 6 6 6 7 7 7 7 8 8 8 8 9 9 9 9 10 10 10 10 11 11 11 11 12 12 12 12 13 13 13 13 14 14 14 14 15 15 15 13
# 13 15 15 15 14 14 14 14 13 13 13 13 12 12 12 12 11 11 11 11 10 10 10 10 9 9 9 9 8 8 8 8 7 7 7 7 6 6 6 6 5 5 5 5 4 4 4 4 3 3 3 3 2 2 2 2 1 1 1 1 0 0 0 2
