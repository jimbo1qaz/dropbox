# TRUMPET:

# intro: 0x1d
# 	(2a03: 1/4: 0x32.8)
# mid: time[0x17.8, 0x22.8]
# 3/4: top=0x29.8, bott=0x22.8

import numpy as np


def morgify(a):
	a = a.split()
	for i, x in enumerate(a):

		y = int(x.split('.')[0], 16)
		if '.' in x:
			y += 0.5
		a[i] = y
	a = np.array(a, dtype=float) / max(a) * 15
	print(a)

print('\n\nbrass')

morgify(a)
# intro: 1d
# mid: 17.8, 22.8
# 3/4: 29.8 / 22.8

# 15    12.4698 10.4819 8.4939759 ]
# intro = A
# mid = 8,C... F E
# 3/4 = F/C

print('\n\nstrings')
morgify('9.5 14.5   0   1b.5 11   0   22.5 1d 25.5   0   17.5 14.5 11')

print('\n\nflute')
morgify('')
