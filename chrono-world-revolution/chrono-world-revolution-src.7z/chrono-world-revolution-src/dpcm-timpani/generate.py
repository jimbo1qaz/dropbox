import scipy.io.wavfile

note2letter = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']


pitches = [3,2,1,0,-1, -7]

rate0, data = scipy.io.wavfile.read('spc_37 timpani.wav')

for delta in pitches:
	rate1 = round(rate0 * 2 ** (delta/12))
	name = f'{note2letter[delta%12]} {hex(rate1)[2:]}.wav'
	scipy.io.wavfile.write(name, rate1, data)
