# TRUMPET:

# intro: 0x1d
# 	(2a03: 1/4: 0x32.8)
# mid: time[0x17.8, 0x22.8]
# 3/4: top=0x29.8, bott=0x22.8

import os
import numpy as np
import pandas as pd
import re
import csv
import webbrowser
from global_util import *


def morgify(a):
    for i, x in enumerate(a):
        if not x:
            a[i] = 0
            continue

        y = int(x.split('+')[0], 16)
        if '+' in x:
            y += 0.5
        a[i] = y
    a = np.array(a, dtype=float) / max(a) * 15
    return a

def pmorgify(a):
    print(morgify(a))


inpath = 'volume-calc.tsv'
with open(inpath) as infile:
    data = csv.reader(infile, delimiter='\t')

    data = list(data)
    # data2 = list(data)
    data2 = []
    # stuff = []

    # print(data)

    skip = False
    for i,row in enumerate(data):
        if skip:
            skip = False
            continue

        data2.append(row)
        row = [cell.strip() for cell in row]
        if all(cell == '' for cell in row):
            continue

        if all(set(cell) <= set('0123456789abcdef+') for cell in row):
            print(i, row)
            row2 = [x if x else '' for x in morgify(row)]
            data2.append(row2)

            # Skip the old transformation.
            if i+1 < len(data) and all(set(cell) <= set('0123456789.') for cell in data[i+1]):
                skip = True


    # # printer = np.vectorize(lambda x:'{0:5}'.format(x,))
    #
    # out = []
    # for label, row in stuff:
    #     row = morgify(row)
    #     # print(np.array(label_row))
    #     out.extend([label, list(row), []])


outpath = 'out.tsv'
# os.rename(inpath, inpath + '.old')
with open(outpath, 'w', newline='') as outfile:
    # for row in out:
    #     print(row)
    w = csv.writer(outfile, delimiter='\t')
    # w.writerows(out)
    w.writerows(data2)

webbrowser.open(outpath)





# pmorgify(a)
# # intro: 1d
# # mid: 17.8, 22.8
# # 3/4: 29.8 / 22.8

# # 15    12.4698 10.4819 8.4939759 ]
# # intro = A
# # mid = 8,C... F E
# # 3/4 = F/C

# print('\n\nstrings')
# morgify('9.5 14.5   0   1b.5 11   0   22.5 1d 25.5   0   17.5 14.5 11')

# print('\n\nflute')
# morgify('')
