# 39 ticks, 2 wah = 60 deltas.
import sys
sys.path.append('..')
from gauss import sprint

tick = -1
ntick = 39
nwave = 60
maxwave = 32

out = []
for i in range(nwave):
    print(i)
    tick2 = i * ntick // nwave
    if tick2 <= tick:
        continue
    tick = tick2

    i -= i // (nwave//2) * (nwave//2)

    # if i >= maxwave:
    #     i = 2*maxwave - i - 1
    print('\t', i)
    out.append(i)

sprint(out)
