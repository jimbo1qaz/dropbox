# import hashlib
import random
from typing import Dict, List

import numpy as np
import scipy.signal
from scipy.io import wavfile
import matplotlib.pyplot as plt

import sys
import struct
sys.path.append("..")   # kill me
import gauss
from global_util import *

# def norm(x):
#     return x / abs(x)


def halved_elements(n):
    return slice(1, (n+1) // 2)



class Fft:
    SINE = True
    welp = -0.5 if SINE else 0


    def __init__(self, data, resynthesize, beta=None, n=None):

        if isinstance(data, np.ndarray):
            self.data = data.astype(float)
        else:
            self.data = np.asarray(data, float)     # not guaranteed to copy ndarray
        self.resynthesize = resynthesize
        del data

        self.n0 = len(self.data)

        if resynthesize:
            window = scipy.signal.kaiser(self.n0, beta=beta)
        else:
            window = np.ones(self.n0)

        self.data *= window

        self.fft = np.fft.rfft(self.data, n)
        self.fft[halved_elements(self.n0)] *= 2


    def rand_fft_phase(self):
        return np.pi * (random.randint(0, 1) - welp) * 1j

    # _seed = 100012863
    _seed = 100000878
    @staticmethod
    def fft_seed(n, num_seed=_seed):
        # dot product of spirals
        seed = int2bytes(num_seed, 16)
        random.seed(seed)

        out = [0]
        for i in range(1, n):
            _, phase = rand_fft_phase(), rand_fft_phase()
            out.append(phase)
        return ar(out)


    # def window
    # def filter(self, freqs):
    #     self.fft *= freqs[:len(self.fft)]

    def filter_time(self, signal, strength):
        # FIXME pad n0

        if strength:
            freqs = Fft(signal, False, n=self.n0).fft
            freqs **= strength
        else:
            freqs = np.ones(self.n0//2 + 1)

        self.fft *= freqs


    def synthesize(self):
        short = np.copy(self.fft[:nout//2 + 1])
        short[halved_elements(nout)] /= 2
        return np.fft.irfft(short, nout)



class Slicer:
    # def sliced(self, ):
    def __init__(self, name, skip):
        _, self.ys = wavfile.read(name)
        if skip not in range(len(self.ys)):
            raise ValueError('invalid skip')
        self.ys = self.ys[skip:]
        self.nsamples = len(self.ys)


    def looped(self, MAXN, nperiods, nsegments, FUNDAMENTAL=1):

        # Produce nsegments segments out of $periods.
        # Then
        segments = np.linspace(0, nperiods, num=nsegments+1)
        segments = [int(round(period)) for period in segments]

        period = int(self.nsamples / nperiods)

        self.waves = []
        self.out = []

        for i, p0 in enumerate(segments[:-1]):
            p1 = segments[i + 1]
            print(f'wave {i}: {p0} to {p1}')

            wave = self.encode(p0 * period, p1 * period, p1 - p0)
            self.waves.append(wave)
            self.out += [i] * (p1 - p0)


    FILTER_STRENGTH = 0
    def encode(self, sample0, sample1, periods):
        # N163 phase is random. No sense in *not* resynthesizing.
        fft = Fft(self.ys[sample0:sample1],
                  resynthesize=True, beta=periods-1)

        fft.filter_time(gauss.l(128), self.FILTER_STRENGTH)
        fft.synthesize()

















# def main(fname, MAXN, rate, periods=None, FPS=60, skip=0, segments=None, nsegments=None, FUNDAMENTAL=1, OFFSET=0):
#
#
#     _, ys = wavfile.read(fname)
#     ys = ys.astype(float)[skip:]
#
#
#     f0 = nsamples / periods
#
#
#
#
#
#
#
#     def get_wave_pos(wavepos0, periods):
#         return get_wave(fuckfuck * wavepos0, periods)
#
#
#
#
#     # EXCLUDE = False
#     # if EXCLUDE:
#     #     END_HARMONIC = (MAXN + 1) // 2      # This reduces length of FFT. BAAD.
#     # else:
#     END_HARMONIC = MAXN // 2 + 1
#
#     # phases = []
#
#     outs = []    # type: List[int]
#     waves = []    # type: List[np.ndarray]
#     # wave_scale = []
#
#     in2out = {} # type: Dict[int, int]
#
#     fuckfuck = rate // FPS
#
#     frame = 0
#     for idx, wavepos0 in enumerate(segments[:-1]):
#         wavepos1 = segments[idx+1]
#         print(f'wave {idx}: {wavepos0} to {wavepos1}')
#         periods = wavepos1 - wavepos0
#
#         wave = get_wave_pos(wavepos0, periods)
#         # TODO: wave[0]?
#         waves.append(wave)
#
#         while frame < wavepos1:
#             outs.append(idx)
#             frame += 1
#
#         del wave
#
#
#     def pwr(yss):
#         return np.average(yss ** 2)
#
#     def normalized():
#         # TODO this
#         segm = []
#         nseg = segments[-1]
#         # ys segment by fuckfuck
#         for i in range(segments[-1]):
#             segm.append(ys[fuckfuck*i : fuckfuck*(i+1)])
#
#         volumes = al(pwr(segm[i]) / pwr(waves[outs[i]] - 7.5) for i in range(nseg)) ** 0.5
#
#         outputs = gauss.rescale_quantize(volumes, maxrange=30, do_round=True)
#         print(S(outputs))
#
#     normalized()



class Writer:

    def asdf(self):
        nframes = len(outs)
        wavecount = len(waves)
        looppoint = nframes - 1

        fname = fname + '.fti'
        with open(fname, 'wb') as f:
            def pstring(nbytes, data):
                # def int2bytes(value: int, nbytes, endian=False):
                return int2bytes(len(data), nbytes, True) + data

            fwrite(f, b"FTI", b"2.4", b"\x05", pstring(4, fname._encode()))
            fwrite(f, bytearray([5, 0, 0, 0, 0, 1]))
            fwrite(f, struct.pack(b"<IiiI", nframes, looppoint, -1, 0))
            for idx in outs:
                fwrite(f, int2bytes(idx, 1))
            fwrite(f, struct.pack(b"<III", MAXN, 0, wavecount))
            for ys in waves:
                fwrite(f, bytes(list(ys)))

    def fwrite(self, f, *args):
        f.write(b''.join(args))


def nearest(bounds, ins):
    ins = list(ins)
    if sorted(ins) != ins:
        raise ValueError('not sorted')

    out = []
    j = 0
    for frame in range(*bounds):
        while j+1 < len(ins) and abs(frame - ins[j+1]) < abs(frame - ins[j]):
            j += 1
        out.append(ins[j])

    return out


if __name__ == '__main__':
    # timpani missing fundamental
    import cProfile
    # cProfile.run("""""")
    # numpy.unique([round(2**(i/2.7)) for i in range(45)])[:16]
    # lol = list(np.unique([int(2**(i/2.7)) for i in range(-1, 45)])[:17])
  # lol = [0 ,1 ,2 ,3 ,4 ,6 ,8 ,12,16,24,32,40,48,56,64,72,80]
    lol = [0 ,3 ,6 ,9 ,12,15,18,21,24,28,32,40,48,56,64,72,80]
    print(lol)
    MAXN = 24
    # OFFSET = MAXN//2
    OFFSET = 0
    # main(fname='spc_37.wav', MAXN=MAXN, FUNDAMENTAL=2, segments=lol, OFFSET=OFFSET, SKIP=16)

    MAXWAVE = 16    # N163 limit

    # 829 blocks, 3 skipped, 397 periods.
    skip = 16*3
    slicer = Slicer('spc_33 strings.wav', skip=48)
    slicer.looped(nperiods=396, nsegments=16)


