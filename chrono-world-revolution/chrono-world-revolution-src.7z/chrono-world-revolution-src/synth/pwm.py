from new import *


def pwm():
    maxn = 64
    half = maxn//2
    nwave = 16
    waves = []

    is_doubled = 0
    for x in np.linspace(half, maxn - 1, nwave):
        x = iround(x)
        wave = ar([0.0] * maxn)
        wave[x:] = 1.0
        # if x == maxn:
        #     is_doubled += 1
        #     wave[x//2-1] = wave[x-1] = 1
        #
        wave = gauss.circular_convolve(wave, gauss.l(128))
        waves.append(wave)

    for x in np.linspace(half+1, maxn - 1, nwave):
        x = iround(x)
        wave = ar([0.0] * maxn)
        wave[half:x] = 1.0
        wave = gauss.circular_convolve(wave, gauss.l(128))
        waves.append(wave)

    # for wave in waves:
    #     wave[:] = gauss.circular_convolve(wave, gauss.l(128))

    if is_doubled != 0:
        raise ValueError

    instr = Instrument()
    instr.load_looped('pwm/pwm', nwave, ys=waves, out_freq=None)
    instr.waves = waves
    instr.set_indexes()
    instr.quantize_all()

    print(len(instr.out))

    instr.write(loop=0)


if __name__ == '__main__':
    pwm()
