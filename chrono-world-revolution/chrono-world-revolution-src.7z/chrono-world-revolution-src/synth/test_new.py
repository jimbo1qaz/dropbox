import os

import pytest

import new
from new import *


NAME = 'samples/square1cyc.wav'

# **** FFT ****
@pytest.fixture
def fft():
    _, ys = wavfile.read(NAME)
    fft = Fft(ys)
    return fft


def test_fft_window(fft: Fft):
    with pytest.raises(ValueError):
        fft.window([])
    with pytest.raises(ValueError):
        fft.window([1.0])

    fft.window([1.0] * fft.n0)


def test_fft_fourier(fft: Fft):
    ys0 = np.copy(fft.ys)
    fft.window([1] * fft.n0)
    fft.fourier()
    assert any(fft.fft)

    nout = 16
    out = fft.synthesize(nout)
    # assert all(abs(out - ys0) / (abs(ys0) + 1e-15) < 1e-15)
    assert any(out)
    assert len(out) == nout










# **** INSTRUMENT ****

sample_rate = 28800
# time = (1/1) * 480smp / rate = 1/60s
# Original rate = 48000 sps = 100 cps.
# Fake rate = 28800 sps = 60 cps = exactly 1 frame's worth of output.
# = nsamples(480) * FPS(60)
@pytest.fixture
def instr():
    instr = Instrument()
    # instr.load_looped('samples/spc_33 strings.wav', skip=48, start=0, periods=396)
    instr.load_looped(NAME, skip=0, periods=1, out_freq=None)
    return instr


def test_properties(instr: Instrument):
    assert any(instr.ys)
    assert instr.period == len(instr.ys) == instr.nsamples


def test_slice(instr: Instrument):
    instr.slice(nwaves=1)

    with pytest.raises(ValueError):
        instr.slice(nwaves=2)
    with pytest.raises(ValueError):
        instr.slice(nwaves=0)
    with pytest.raises(ValueError):
        instr.slice(nwaves=-1)


def test_resynth(instr: Instrument):
    instr.slice(nwaves=1)

    maxn = 16
    instr.resynth(wavelen=maxn, do_rephase=False)
    # assert all(instr.waves)
    assert len(instr.waves) == len(instr.out) == 1  # screw around with get_wave_idx

    assert any(instr.waves[0])

    # **** How to make FFT symmetric? ****
    # assert list(instr.waves[0]) == [15]*8 + [0]*8
    # I added special code to ensure FFTs are processed symmetrically.
    # But I still lose the edge peaks for some reason...
    half=maxn//2
    expected = [14] + [15]*(half-2) + [14, 1] + [0]*(half-2) + [1]
    assert list(instr.waves[0]) == expected

    assert instr.out[0] == 0    # wave index #0

    instr.write()
    assert os.path.exists(NAME + '.fti')


def test_strings():
    instr = Instrument()
    instr.load_looped('samples/spc_33 strings.wav', 396, skip=48, out_freq=32000)
    instr.slice(nwaves=16)
    instr.resynth(wavelen=16)

    assert all(wave_idx < 16 for wave_idx in instr.out)

    assert 16 <= len(instr.out) < 256
    assert len(instr.waves) == instr.out[-1] + 1

    instr.write(loop=0)


def test_encode_small(instr: Instrument):
    instr.maxn = 16
    assert any(instr._encode(0, instr.period, 1, quantize=False))


def test_encode_big(instr: Instrument):
    instr.maxn = 16
    assert any(instr._encode(0, 100 * instr.period, 1, quantize=False))
