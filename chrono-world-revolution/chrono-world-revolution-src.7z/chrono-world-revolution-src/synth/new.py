# import numpy as np
import random

import scipy.signal
import struct
from scipy.io import wavfile

import sys
sys.path.append('..')
import gauss
from global_util import *
import optimal_saw



def symm_decode(fft_arr, n):
    """ periodic FFT to symmetric lolfft """
    out = np.copy(fft_arr)
    for i, _ in enumerate(out):
        out[i] /= gauss.ei(np.pi * i / n)
    return out


def symm_encode(fft_arr, n):
    """ symmetric lolfft to periodic FFT"""
    out = np.copy(fft_arr)
    for i, _ in enumerate(out):
        out[i] *= gauss.ei(np.pi * i / n)
    return out

class Fft:
    muls = None

    def __init__(self, ys):
        if isinstance(ys, np.ndarray):
            self.ys = ys.astype(float)
        else:
            self.ys = np.asarray(ys, float)     # not guaranteed to copy ndarray

        self.n0 = len(ys)

    def window(self, window):
        if len(window) != self.n0:
            raise ValueError('improper window fuck')
        # TODO cast to int
        self.ys *= window

    def fourier(self):
        raw_fft = np.fft.rfft(self.ys)
        self.fft = symm_decode(raw_fft, self.n0)

    def rephase(self, do_rephase, periods, fundamental=1, COMBINE=sum):
        end_harmonic = gauss.nyquist_inclusive(self.n0 // periods)

        # Build a FFT with the total magnitude around each bin.
        if do_rephase:
            self.fft = abs(self.fft)
        fft2 = []
        for harmonic in range(end_harmonic):
            if harmonic < fundamental:
                fft2.append(0)
                continue
            fft_idx = harmonic * periods

            # Sample around the desired harmonic.
            accum = slice(fft_idx - periods // 2, fft_idx + periods // 2 + 1)  # inclusive
            bins = self.fft[accum]
            fft2.append(COMBINE(bins) if len(bins) else 0)

        self.fft = fft2
        if do_rephase:
            self.fft *= ar(self.muls)[:end_harmonic]

    def filter(self, filter):
        thing = np.fft.rfft(filter, self.n0)
        self.fft *= abs(thing)

    def synthesize(self, nout):
        raw_fft = self.fft[:nout//2 + 1]
        raw_fft = symm_encode(raw_fft, nout)
        return np.fft.irfft(raw_fft, nout)

# ODD=True, 2749, bad.
# ODD=False, 3218, good.
seed = 2749
optimal_saw.ODD = True
Fft.muls = optimal_saw.get_rand_muls(seed, n=6669)


FPS = 60
class Instrument:
    def get_wave_idx(self, periods):
        if self.out_freq is None:
            return periods
        # time = (periods/nperiods) * nsamples / samples/s = 1/fps * @frames
        # @frames = (periods/nperiods) * len(ys) * fps / rate
        return int(periods / self.nperiods * self.nsamples * FPS / self.out_freq)

    def initialize(self, name, waves):
        # if ys is None:
        #     ys = []

        self.name = name
        self.waves = waves
        return self

    def load_looped(self, name, periods, out_freq, ys=None, skip=0, fundamental=1):   # start=0
        """ When performing unit tests, set out_freq to None, to play each waveform for 1 frame. """
        self.name = name
        if ys is not None:
            self.ys = ys
        else:
            _, self.ys = wavfile.read(name)
        if skip not in range(len(self.ys)):
            raise ValueError('invalid skip')
        self.ys = self.ys[skip:]
        self.nsamples = len(self.ys)
        self.out_freq = out_freq
        self.fundamental = fundamental

        # self.start = start
        self.nperiods = periods
        self.period = int(self.nsamples / self.nperiods)
        return self

    def slice(self, nwaves):
        self.dividers = ROUND(np.linspace(0, self.nperiods, num=nwaves + 1)) \
            # boundaries between wave segments.
        if nwaves > self.nperiods:
            raise ValueError(f'Too many waves! {nwaves} > {self.nperiods}')

        if nwaves <= 0:
            raise ValueError(f'Invalid wave count {nwaves}')

    def resynth(self, wavelen, quantize=True, do_rephase=True, filter=None):
        self.waves = []
        self.out = []
        self.maxn = wavelen
        dividers = self.dividers
        for i, p0 in enumerate(dividers[:-1]):      # period0, period1
            p1 = dividers[i + 1]
            print(f'wave {i}: {p0} to {p1} periods')

            wave = self._encode(p0 * self.period, p1 * self.period, p1 - p0,
                                quantize=quantize, do_rephase=do_rephase, filter=filter)

            self.waves.append(wave)
            target_outlen = self.get_wave_idx(p1)
            self.out += [i] * (target_outlen - len(self.out))

    def set_indexes(self, out=None):
        if out is None:
            out = [i for i,_ in enumerate(self.waves)]
        self.out = [int(waveidx) for waveidx in out]

        wave0 = self.waves[0]
        if not all(len(wave) == len(wave0) for wave in self.waves):
            raise ValueError('Inconsistent wave lengths')

        self.maxn = len(wave0)

    def quantize_all(self):
        # for wave in self.waves:
        #     wave -= (np.min(wave) + np.max(wave)) / 2
        self.waves = gauss.rescale_quantize(np.stack(self.waves))

    def _encode(self, sample0, sample1, periods, quantize, do_rephase=True, filter=None):
        fft = Fft(self.ys[sample0:sample1])

        window = scipy.signal.kaiser(fft.n0, beta=periods-1)
        fft.window(window)
        fft.fourier()
        fft.rephase(do_rephase, fundamental=self.fundamental, periods=periods)
        fft.filter(filter)
        out = fft.synthesize(self.maxn)

        if quantize:
            out = gauss.rescale_quantize(out)
        return out

    def write(self, fname=None, loop=None, offset=0):
        nframes = len(self.out)
        wavecount = len(self.waves)
        if loop is None:
            loop = nframes - 1

        if fname is None:
            fname = self.name + '.fti'
        with open(fname, 'wb') as f:
            def pstring(nbytes, data):
                # def int2bytes(value: int, nbytes, endian=False):
                return int2bytes(len(data), nbytes, True) + data

            fwrite(f, b"FTI", b"2.4", b"\x05", pstring(4, fname.encode()))
            fwrite(f, bytearray([5, 0, 0, 0, 0, 1]))
            fwrite(f, struct.pack(b"<IiiI", nframes, loop, -1, 0))
            for idx in self.out:
                fwrite(f, int2bytes(idx, 1))
            fwrite(f, struct.pack(b"<III", self.maxn, offset, wavecount))    # nsamp, index, nwave
            for wave in self.waves:
                fwrite(f, bytes(list(wave)))


def fwrite(f, *args):
    f.writelines(args)
    # f.write(b''.join(args))



def strings():
    instr = Instrument()
    # instr.load_looped('samples/spc_33 strings.wav', 396, skip=48, out_freq=32000)
    instr.load_looped('samples/spc_33 strings.wav', 396, skip=48, out_freq=4000)
    instr.slice(16)
    instr.resynth(wavelen=32, quantize=True)
    # instr.quantize_all()

    instr.write(loop=0, fname='samples/low-strings.fti')

    instr.out = instr.out[::8]
    instr.write(loop=0, fname='samples/high-strings.fti')


def pwm():
    maxn = 64
    nwave = 16
    waves = []

    is_doubled = 0
    for x in np.linspace(maxn//2, maxn - 1, nwave):
        x = iround(x)
        wave = ar([0.0] * maxn)
        wave[x:] = 1.0
        # if x == maxn:
        #     is_doubled += 1
        #     wave[x//2-1] = wave[x-1] = 1
        #
        wave = gauss.circular_convolve(wave, gauss.l(128))
        waves.append(wave)

    if is_doubled != 0:
        raise ValueError

    instr = Instrument()
    instr.load_looped('pwm/pwm', nwave, ys=waves, out_freq=None)
    instr.waves = waves
    instr.out = [i for i,_ in enumerate(waves)]
    instr.maxn = maxn
    # instr.slice(16)
    # instr.resynth(wavelen=maxn, quantize=False, do_rephase=False, filter=gauss.GAUSS)
    instr.quantize_all()

    print(len(instr.out))

    instr.write(loop=0)


def rsum2(*args):
    return np.sqrt(sum(arg**2 for arg in args))

def rmean2(*args):
    return np.sqrt(np.average(arg**2 for arg in args))



def norm(x):
    return x / abs(x)

def merge(primary, secondary, frac2):
    """ Combines the power of $primary and $secondary, preserving $primary phase."""
    
    f1 = np.fft.rfft(primary)
    f2 = np.fft.rfft(secondary)
    
    for f in range(len(f1)):
        angle2 = f1[f]
        if abs(angle2) < 1e-3:
            angle2 = f2[f]

        frac1 = 1-frac2
        f1[f] = rsum2(frac1 * f1[f], frac2 * norm(angle2)*abs(f2[f]))
    
    return np.fft.irfft(f1, n=len(primary))

def merge_balanced(primary, secondary, frac2):
    """ Combines the power of $primary and $secondary, with the sum phase."""
    
    f1 = np.fft.rfft(primary)
    f2 = np.fft.rfft(secondary)
    
    for f in range(len(f1)):
        angle2 = f1[f]
        if abs(angle2) < 1e-3:
            angle2 = f2[f]

        frac1 = 1-frac2
        rmsAmp = rsum2(abs(frac1 * f1[f]), abs(frac2 * f2[f]))
        f1[f] = rmsAmp * norm(f1[f] + f2[f])
    
    return np.fft.irfft(f1, n=len(primary))


if __name__ == '__main__':
    print('see pwm.py')
    # print('start')
    # strings()
    # pwm()
