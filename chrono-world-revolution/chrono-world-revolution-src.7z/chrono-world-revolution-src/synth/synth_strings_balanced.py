import sys

sys.path.append(r'.')

from new import *
import random

factor_rand = 0.33
phase_rand = 0.75


def fac(x):
    return x * random.uniform(1 - factor_rand, 1 + factor_rand)

def pha():
    return random.uniform(0, phase_rand)


def rotate_left(arr, n):
    return cat(arr[n:], arr[:n])


def phase_distortion(nsamp, omega, max_harmonic=4):
    max_harmonic = nsamp // 2

    wave = np.zeros(nsamp)

    xs = al(i - nsamp/2 + 0.5 for i in range(nsamp))

    for harmonic in range(1, max_harmonic+1):

        if harmonic > 1:
            factor = fac(0.5 ** harmonic)
        else:
            factor = 1

        harmonic_phase = pha()
        wave += np.sin([harmonic * (harmonic_phase + i*omega) for i in xs]) * factor

    wave *= np.linspace(1, 0, nsamp+1)[:-1] * np.linspace(0, 1, nsamp+1)[1:] * 4
    return wave


TW = 12

def synth_str_rphase(nsamp=32, nwave=16):
    start = 1
    stop = 2
    delta = stop - start

    waves = []  # type: list(np.array(float))
    instr = Instrument()
    instr.initialize('strings/stringsBalanced', waves)
    for waven in range(TW+1):
        waven *= 2
        omega = (start*nsamp + delta*waven) / nsamp / nsamp
        omega *= TAU

        # print(nsamp*omega / TAU)

        wave = phase_distortion(nsamp, omega)
        waves.append(wave)

    # we cycle through [0..12..0]. At the highest note, that's about correct.
    assert TW == 12
    waves[:] = waves[:TW+1]

    indexes = al(range(TW))
    indexes = cat(indexes, TW - indexes)
    instr.set_indexes(indexes)

    assert waves is instr.waves
    # instr.quantize_all()
    waves[:] = [gauss.rescale_quantize(wave) for _,wave in enumerate(instr.waves)]

    for wave in waves:
        print(S(wave), ';')

    instr.write(loop=0, offset=96)


if __name__ == '__main__':
    # synth_str_2()
    synth_str_rphase()
