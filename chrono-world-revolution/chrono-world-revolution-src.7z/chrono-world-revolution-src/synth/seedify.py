import hashlib
import random

import sys

import numpy as np

sys.path.append("..")   # kill me
import gauss
from global_util import *


def rand_phase():
    return np.pi * (random.randint(0, 1) - 0.5)


def seedify(n, num_seed=100012863):
    seed = int2bytes(num_seed, 16)
    random.seed(seed)

    out = [0]
    for i in range(1, n):
        _, phase = rand_phase(), rand_phase()
        out.append(phase)
    return ar(out)

signs = seedify(n=256)
