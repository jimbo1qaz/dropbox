# import hashlib
import random
from typing import Dict, List

import numpy as np
import scipy.signal
from scipy.io import wavfile
import matplotlib.pyplot as plt

import sys
import struct
sys.path.append("..")   # kill me
import gauss
from global_util import *

# def norm(x):
#     return x / abs(x)

# In [4]: np.fft.rfft([1], n=16)
# Out[4]:
# array([ 1.+0.j,  1.+0.j,  1.-0.j,  1.+0.j,  1.+0.j,  1.+0.j,  1.+0.j,
#         1.+0.j,  1.+0.j])

# UNNECESSARY.
# def halved_elements(n):
#     return slice(1, (n+1) // 2)



class Fft:
    SINE = True
    welp = -0.5 if SINE else 0


    def __init__(self, data, resynthesize, beta=None, n=None):

        if isinstance(data, np.ndarray):
            self.data = data.astype(float)
        else:
            self.data = np.asarray(data, float)     # not guaranteed to copy ndarray
        self.resynthesize = resynthesize
        del data

        self.n0 = len(self.data)

        if resynthesize:
            window = scipy.signal.kaiser(self.n0, beta=beta)
        else:
            window = np.ones(self.n0)

        self.data *= window

        self.fft = np.fft.rfft(self.data, n)
        # self.fft[halved_elements(self.n0)] *= 2


    def get_rand_phases(self, seed, nout):
        random.seed(seed)
        yield 1
        for i in range(1000000000):
            # half-sample shift.
            mul = np.exp(1j * np.pi * i/nout)
            if random.randint(0, 1):
                mul *= -1
            yield mul


    def synthesize(self, nout):
        short = np.copy(self.fft[:nout//2 + 1])
        # short[halved_elements(nout)] /= 2
        return np.fft.irfft(short, nout)



class Slicer:
    # def sliced(self, ):
    def __init__(self, name, skip):
        _, self.ys = wavfile.read(name)
        if skip not in range(len(self.ys)):
            raise ValueError('invalid skip')
        self.ys = self.ys[skip:]
        self.nsamples = len(self.ys)


    def looped(self, maxn, nperiods, nsegments, FUNDAMENTAL=1):

        # Produce nsegments segments out of $periods.
        # Then
        segments = np.linspace(0, nperiods, num=nsegments+1)
        segments = [int(round(period)) for period in segments]

        period = int(self.nsamples / nperiods)

        self.waves = []
        self.out = []
        self.maxn = maxn

        for i, p0 in enumerate(segments[:-1]):
            p1 = segments[i + 1]
            print(f'wave {i}: {p0} to {p1}')

            wave = self.encode(p0 * period, p1 * period, p1 - p0)
            self.waves.append(wave)
            self.out += [i] * (p1 - p0)


    FILTER_STRENGTH = 0
    def encode(self, sample0, sample1, periods):
        # N163 phase is random. No sense in *not* resynthesizing.
        fft = Fft(self.ys[sample0:sample1],
                  resynthesize=True, beta=periods-1)

        # todo: fuck around with phases

        return fft.synthesize(self.maxn)

    def write(self):
        # TODO
        pass




class Writer:

    def asdf(self):
        nframes = len(outs)
        wavecount = len(waves)
        looppoint = nframes - 1

        fname = fname + '.fti'
        with open(fname, 'wb') as f:
            def pstring(nbytes, data):
                # def int2bytes(value: int, nbytes, endian=False):
                return int2bytes(len(data), nbytes, True) + data

            fwrite(f, b"FTI", b"2.4", b"\x05", pstring(4, fname._encode()))
            fwrite(f, bytearray([5, 0, 0, 0, 0, 1]))
            fwrite(f, struct.pack(b"<IiiI", nframes, looppoint, -1, 0))
            for idx in outs:
                fwrite(f, int2bytes(idx, 1))
            fwrite(f, struct.pack(b"<III", MAXN, 0, wavecount))
            for ys in waves:
                fwrite(f, bytes(list(ys)))

    def fwrite(self, f, *args):
        f.writelines(args))
        # f.write(b''.join(args))



if __name__ == '__main__':
    MAXN = 24

    # 829 blocks, 3 skipped, 397 periods, but wave is funky.
    slicer = Slicer('spc_33 strings.wav', skip=48)
    slicer.looped(maxn=MAXN, nperiods=396, nsegments=16)


