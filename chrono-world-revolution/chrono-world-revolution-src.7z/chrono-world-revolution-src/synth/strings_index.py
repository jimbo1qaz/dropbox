import random
from global_util import *


# first = 2 # FIXME
last = 12
halfn = 10
rng = 1


def get_outs():

    outs = []
    prev = 0
    for idx in range(halfn):
        outs.append(prev)
        if idx+1 == halfn:
            continue

        out = prev
        while 1:
            to = RANGE(out, last, halfn-idx)
            out = list(to)[1]
            out += random.uniform(-rng, rng)

            out = int(round(out))
            out = max(out, 0)
            out = min(out, last)

            if out != prev:
                break
        prev = out

    return ar(outs)

def get_bidi():
    bidi = cat(get_outs(), last - get_outs())
    return bidi

if __name__ == '__main__':
    print(bidi())
