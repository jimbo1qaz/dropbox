from new import *


def synth_str(synth_ratio=0.25):
    nsamp = 16
    nwave = 16
    waves = []


    for waven in range(nwave//2, nwave):
        turning = waven * nsamp // nwave

        wave = np.zeros(nsamp)

        wave = []
        for samp in range(turning):
            wave.append(samp/turning)
        for samp in range(turning, nsamp):
            wave.append(1 - (samp-turning) / (nsamp-turning))

        waves.append(wave)

    for wave in waves:
        wave[:] = gauss.circular_convolve(wave, gauss.l(128))
    #     wave[:] = gauss.circular_convolve(wave, gauss.l(128))

    instr = Instrument()
    instr.load_looped('strings/strings', nwave, ys=waves, out_freq=None)
    instr.waves = waves
    instr.linear(out=I('2 2 2 3 3 3 4 4 4 5 5 5 6 6 6 5 5 5 4 4 4 3 3 3'))
    # instr.linear(out=I('0 1 2 3 4 5 6 7 8 7 6 5 4 3 2 1'))
    instr.quantize_all()

    print(len(instr.out))

    instr.write(loop=0)


if __name__ == '__main__':
    synth_str()
