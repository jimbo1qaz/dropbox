import hashlib
import math
import random
import numpy as np

import scipy.signal
from scipy.io import wavfile

from fractions import Fraction

import matplotlib.pyplot as plt


# FIXME: if sum(delta^2) is constant... Then the aliasing power is constant. I'm wasting my fucking time.
# Should I judge based on rounding error?
# TODO: calculate FFT of np.LOLGAUSS, insert into BASS_BOOST, rename
# BASS_BOOST.

import sys
sys.path.append("..")   # kill me
import gauss
from global_util import *


# 5504 samples/sec
# 60 cyc/sec
# 5504/60 samp/cyc

def norm(x):
    return x / abs(x)


class Slicer:
    def get_wave(self, sample0):
        block = self.ys[sample0:samples0 + self.nsamples]

        fft = np.fft.rfft(block)
        del block
        fft = fft[:MAX_HARMONIC]

        fft[0] = 0                          # dc bias

        fund = fft[FUNDAMENTAL]
        # HELP phases.append(np.angle(fft, deg=True)[FUNDAMENTAL:])
        fft /= norm(fund)       # common phase

        fft[-1] = abs(fft[-1])              # emphasize last harmonic, cosine term

        output = np.fft.irfft(fft)
        return gauss.rescale_quantize(output)

    def get_at_frame(self, frameN):
        return self.get_wave(None)

    def load(self, fname, cyc_s, MAXN, samp_s=None, f_s=60, FUNDAMENTAL=1):
        self.wav_rate, self.ys = wavfile.read(fname)
        self.nsamples = None

        # harmonics: [0..MAXN//2]
        MAX_HARMONIC = MAXN//2 + 1

        if samp_s is None:
            samp_s = wav_rate

        phases = []

        output_scale0 = []
        output_wave = []
        # print(rounded)

        fname = fname + '.fti'
        with open(fname, 'wb') as f:
            f.write("FTI", "2.4", "\x05", string.pack("s4", fname))
            f.write(string.char(5, 0, 0, 0, 0, 1))
            f.write(string.pack("<I4i4i4I4", seqlen, looppoint, -1, 0))
            for i = 1, seqlen do f.write(string.char(math.floor((i - 1) / seqlen * arg.wavecount))) end
            f.write(string.pack("<I4I4I4", #out[1], 0, arg.wavecount))
            for i = 1, arg.wavecount do for _, v in ipairs(out[math.floor((i - 1) * #out / arg.wavecount) + 1]) do
                f.write(string.char(math.min(15, math.max(0, v))))
            end end

        # phases = ar(phases)
        # for i in range(1, len(phases)):
        #     for j in range(len(phases[i])):
        #         phase = phases[..., j]
        #         phases[i:, j] += -360 * round((phase[i] - phase[i-1]) / 360)
        # plt.plot(phases[..., :4])
        # plt.show()




# scipy.signal.resample()

if __name__ == '__main__':
    # timpani missing fundamental
    main(fname='spc_37.wav', cyc_s=60, MAXN=24, samp_s=5504, f_s=60, FUNDAMENTAL=2)
