if fft_frames >= 3:
    window = scipy.signal.hamming(N)
if fft_frames >= 4:
    window = scipy.signal.hann(N)
if
if fft_frames >= 2:
    window = scipy.signal.slepian(len(block), width=1.0)
    plt.plot(window)
    plt.show()
