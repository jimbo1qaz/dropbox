# # sample0_frame = num_frames * sample/frame.
# # sample0_phase = sample0 / sample/cyc * sample/cyc.

samp_f = Fraction(samp_s, f_s)
samp_cyc = Fraction(samp_s, cyc_s)

sample0_frame = frame * samp_f
sample0_phase = round(sample0_frame / samp_cyc) * samp_cyc
sample0 = frame * samp_cyc
sample0 = round(sample0 / samp_f) * samp_f
sampleF = sample0 + samp_cyc
