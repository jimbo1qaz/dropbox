from slicer import *
import numpy as np
# import importlib
# slicer = importlib.import_module('slicer.py')

assert halved_elements(4) == slice(1, 2)
assert len(Fft([0]*4, False).fft) == 3

assert halved_elements(5) == slice(1, 3)
assert len(Fft([0]*5, False).fft) == 3


slicer = Slicer('spc_33 strings.wav', skip=48)
slicer.looped(nperiods=396, nsegments=16, maxn=16)

assert slicer.waves, slicer.out
assert any(slicer.waves[0])

slicer.write()
