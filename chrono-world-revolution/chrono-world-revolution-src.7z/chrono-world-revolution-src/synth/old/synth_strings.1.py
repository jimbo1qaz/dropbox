from new import *


def synth_str(synth_ratio=0.25):
    nsamp = 16
    nwave = 16
    waves = []


    for waven in range(nwave):
        turning = waven * nsamp // nwave

        wave = np.zeros(nsamp)
        
        alpha = ar([samp % nsamp for samp in range(nsamp)]) * (1-synth_ratio)
        alpha = gauss.circular_convolve(alpha, gauss.l(128))
        alpha = gauss.circular_convolve(alpha, gauss.l(128))

        beta = ar([(turning + samp) % nsamp for samp in range(nsamp)]) * (synth_ratio)

        wave = alpha + beta
        waves.append(wave)

    # for wave in waves:
    #     wave[:] = gauss.circular_convolve(wave, gauss.l(128))
    #     wave[:] = gauss.circular_convolve(wave, gauss.l(128))

    instr = Instrument()
    instr.load_looped('strings/strings.1', nwave, ys=waves, out_freq=None)
    instr.waves = waves
    instr.linear(out=I('2 2 2 3 3 3 4 4 4 5 5 5 6 6 6 5 5 5 4 4 4 3 3 3'))
    instr.quantize_all()

    print(len(instr.out))

    instr.write(loop=0)


if __name__ == '__main__':
    synth_str()
