# def synth_str_2(start=2, stop=3):
#     nsamp = 32
#     nwave = 16
#     waves = []
#
#     delta = stop - start
#
#     for waven in range(nsamp):
#         omega = PI2 * (start*nsamp + delta*waven) / nsamp / nsamp
#
#         wave = np.sin([i*omega for i in range(nsamp)])
#         wave += np.sin([2*i*omega for i in range(nsamp)]) * fac(0.5)
#         wave += np.sin([3*i*omega for i in range(nsamp)]) * fac(0.25)
#         wave += np.sin([4*i*omega for i in range(nsamp)]) * fac(0.125)
#         wave *= np.linspace(1, 0, nsamp)
#
#         waves.append(wave)
#
#     # for wave in waves:
#     #     wave[:] = gauss.circular_convolve(wave, gauss.l(128))
#     waves = waves[::2]
#
#
#     instr = Instrument()
#     instr.load_looped('strings/strings2', nwave, ys=waves, out_freq=None)
#     instr.waves = waves
#     # instr.set_indexes(out=I('2 2 2 3 3 3 4 4 4 5 5 5 6 6 6 5 5 5 4 4 4 3 3 3') - 2)
#     # instr.set_indexes(out=list(range(16)))
#     instr.set_indexes(out=get_bidi())
#     # instr.quantize_all()
#
#     instr.waves = [gauss.rescale_quantize(wave) for wave in instr.waves]
#
#     print(len(instr.out))
#
#     instr.write(loop=0, offset=96)