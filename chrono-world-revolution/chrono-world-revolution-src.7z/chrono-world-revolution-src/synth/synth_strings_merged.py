import sys

sys.path.append(r'.')

from new import *
import random

factor_rand = 0.0
phase_rand = 0.0


def fac(x):
    return x * random.uniform(1 - factor_rand, 1 + factor_rand)

def pha():
    return random.uniform(0, phase_rand)


def rotate_left(arr, n):
    return cat(arr[n:], arr[:n])


def phase_distortion(nsamp, omega, max_harmonic=4):
    max_harmonic = nsamp // 2

    wave = np.zeros(nsamp)

    xs = al(i - nsamp/2 + 0.5 for i in range(nsamp))

    for harmonic in range(1, max_harmonic+1):

        if harmonic > 1:
            factor = fac(0.5 ** harmonic)
        else:
            factor = 1

        harmonic_phase = pha()
        wave += np.sin([harmonic * (harmonic_phase + i*omega) for i in xs]) * factor

    wave *= np.linspace(1, 0, nsamp+1)[:-1] * np.linspace(0, 1, nsamp+1)[1:] * 4
    return gauss.rescale_quantize(wave, do_round='skip')


TW = 12

def synth_str_rphase(nsamp=32, nwave=16, psynth=0.5):
    start = 1
    stop = 2
    delta = stop - start

    waves = []  # type: list(np.array(float))
    instr = Instrument()
    instr.initialize('strings/stringsBalancedMerged' + str(psynth), waves)
    for waven in range(TW+1):
        waven *= 2
        omega = (start*nsamp + delta*waven) / nsamp / nsamp
        omega *= TAU

        # print(nsamp*omega / TAU)

        wave = phase_distortion(nsamp, omega)
        waves.append(wave)

    # we cycle through [0..12..0]. At the highest note, that's about correct.
    assert TW == 12
    waves[:] = waves[:TW+1]

    for i in range(len(waves)):
        waves[i] = merge_balanced(waves[i], zamual[i], psynth)

    indexes = al(range(TW))
    indexes = cat(indexes, TW - indexes)
    instr.set_indexes(indexes)

    assert waves is instr.waves
    # instr.quantize_all()
    waves[:] = [gauss.rescale_quantize(wave) for _,wave in enumerate(instr.waves)]

    for wave in waves:
        print(S(wave), ';')

    instr.write(loop=0, offset=96)


zamual = [
#     F('10 9 5 4 4 4 4 4 4 4 5 6 6 5 5 6 7 7 6 6 6 7 9 11 10 10 11 12 12 11 13 15'),
    F('14 13 4 0 1 3 2 1 1 1 3 7 7 6 4 3 4 6 7 5 4 4 8 13 14 12 12 13 13 12 13 15'),
    F('12 12 6 1 0 2 4 3 2 3 5 6 7 8 5 1 2 4 5 6 5 4 8 12 13 13 13 13 13 11 12 13'),
    F('11 11 8 3 0 0 3 5 4 4 3 4 7 8 5 2 1 1 3 5 6 5 7 11 13 13 14 14 14 13 13 12'),
    F('12 12 9 9 9 7 4 1 1 3 7 7 3 2 4 7 7 4 1 2 4 4 5 7 6 8 11 12 13 12 14 15'),
    F('13 14 10 8 8 10 10 4 0 1 5 6 5 3 2 4 5 3 1 2 4 5 6 6 5 6 11 13 13 12 14 14'),
    F('12 12 5 0 0 3 6 5 3 0 1 3 3 2 4 6 5 4 5 6 8 11 13 13 13 13 12 14 13 8 9 12'),
    F('13 11 3 0 2 6 6 2 0 0 4 7 5 4 4 5 7 7 6 6 9 11 11 10 9 11 12 12 11 10 12 13'),
    F('12 8 2 2 4 4 3 2 1 3 7 7 4 3 5 5 5 8 8 6 8 9 9 9 9 11 15 14 10 9 12 13'),
    F('12 9 3 2 3 4 3 4 4 4 5 6 5 3 3 4 5 6 7 7 7 8 9 10 13 15 12 10 9 8 12 13'),
    F('12 11 6 2 0 1 1 2 6 8 5 3 4 5 3 3 5 5 4 6 8 7 11 14 14 14 14 13 13 10 10 11'),
    F('11 11 6 4 6 8 4 0 0 4 8 9 7 5 5 6 8 7 7 7 5 4 4 5 8 11 12 11 10 9 12 13'),
    F('13 14 11 6 2 4 4 2 0 0 3 7 7 6 6 9 9 8 9 9 7 7 5 2 3 7 10 11 12 10 12 13'),
    F('11 11 7 6 8 9 6 1 0 1 4 7 6 4 4 5 6 10 13 11 10 9 8 8 8 7 7 7 7 6 9 12'),
    F('10 10 6 5 4 3 3 0 0 1 2 4 4 6 8 9 8 7 8 11 14 14 10 6 6 10 13 11 9 9 10 10'),
    F('12 11 8 7 8 9 6 2 0 0 3 3 2 2 4 7 8 7 5 7 9 8 8 8 8 10 12 11 10 10 11 13'),
][:]

if __name__ == '__main__':
    # synth_str_2()
    synth_str_rphase(psynth=0)
    synth_str_rphase(psynth=0.01)
    synth_str_rphase(psynth=0.5)
    synth_str_rphase(psynth=0.99)
    synth_str_rphase(psynth=1)
