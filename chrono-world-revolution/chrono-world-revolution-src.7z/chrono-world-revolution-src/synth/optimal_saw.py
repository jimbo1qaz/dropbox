import math
import random
import numpy as np
import matplotlib.pyplot as plt


import sys
sys.path.append("..")   # kill me
import gauss
from global_util import *

import new

class AttrDict(dict):
    def __init__(self, seq={}, **kwargs):
        super().__init__(seq, **kwargs)
        self.__dict__ = self


max_systematic = 12
NTEST = 2 ** max_systematic

MAXRANGE = 16

ODD = False
# ODD=True increases cost.

def get_rand_muls(num_seed, n=256):
    end_harmonic = gauss.nyquist_inclusive(n)

    muls = []
    seed = int2bytes(num_seed, 16)
    random.seed(seed)

    # assert end_harmonic == len(self.fft)

    for i in range(end_harmonic):
        if i < max_systematic:
            mul = (-1) ** bool(num_seed & 1<<i)
        else:
            mul = (-1) ** random.randint(0,1)

        if ODD:
            mul *= 1j
        muls.append(mul)

    return muls
    # EXAMPLE: fft[i] = mag * mul


def wave_test(n, num_seed):
    end_harmonic = gauss.nyquist_inclusive(n)

    invs = get_rand_muls(num_seed=num_seed, n=n)

    fft_obj = new.Fft([0.0] * n)
    fft_obj.fourier()
    fft = fft_obj.fft

    assert end_harmonic == len(fft)

    for i in range(1, end_harmonic):
        fft[i] = 1/i * invs[i]

    fft[:] = new.symm_encode(fft, n)
    ys = fft_obj.synthesize(n)

    cost, wavetable = gauss.rescale_quantize(ys, ret_tuple=True)

    return AttrDict(cost=cost, seed=num_seed, wavetable=wavetable, invs=invs)


def multitest(samples, seed0=0, NTEST=NTEST):
    # (cost, seed, ys)
    best = AttrDict(cost=math.inf, seed=None, ys=None)

    for seed in range(seed0, seed0 + NTEST):
        result = wave_test(samples, seed)
        if result.cost < best.cost:
            best = result

    return best




def main(infile='seeds.txt', outfile='results.txt'):
    print('start')
    samples = 64

    result = multitest(samples)
    cost, seed, wavetable, invs = [result.cost, result.seed, result.wavetable, result.invs]

    output = f'''{samples}: {seed}: {invs}
    {cost}
{S(wavetable)}
{S(MAXRANGE - wavetable - 1)}

'''

    open(outfile, 'w').write(output)


if __name__ == '__main__':
    main()
